import java.io.*;
import java.net.*;
import java.util.*;

public class Pair {
    Socket first, second;
    Pair(Socket ss1, Socket ss2)
    {
        first = ss1;
        second = ss2;
    }
}
