public class ScoreBoard {
    private int O_wins;
    private int draws;
    private int X_wins;

    public int getDraws() {
        return draws;
    }

    public void setDraws(int draws) {
        this.draws = draws;
    }

    public int getX_wins() {
        return X_wins;
    }

    public void setX_wins(int x_wins) {
        X_wins = x_wins;
    }

    public int getO_wins() {
        return O_wins;
    }

    public void setO_wins(int o_wins) {
        O_wins = o_wins;
    }


}
