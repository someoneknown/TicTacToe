import java.io.*;
import java.net.*;
import java.util.*;
public class VerySimpleChatServer {
    static Socket waitingSocket[];
    static Socket chatmsg, gamemsg;
    int cnt;
    ArrayList<PrintWriter> clientOutputStream;

    public class ClientHandler implements Runnable {
        BufferedReader reader;
        Socket sock;
        Socket msgs;
        int callerid;

        public ClientHandler(Socket clientSocket, int i) {
            try{
                sock = clientSocket;
                callerid=i;
                InputStreamReader isReader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(isReader);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } // close constructor

        public void run() {
            String message;
            try {
                while ((message = reader.readLine()) != null) {
                    if(callerid==1)
                    {
                        //pass this msg to shivansh's class
                        return;
                    }
                    System.out.println("read " + message);
                    tellEveryone(message);
                } // close while
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } // close run
    } // close inner class

    public class RequestListner implements Runnable {
        Socket msgs;
        int indx;

        RequestListner(int i, Socket msg) {
            indx = i;
            msgs = msg;
            clientOutputStream=new ArrayList<>();
        }

        public void run() {
            try {
                ServerSocket serverSock = new ServerSocket(5000);
                while (true) {
                    Socket clientSocket = serverSock.accept();
                    PrintWriter writ=new PrintWriter(clientSocket.getOutputStream());
                    if(indx==1)
                        clientOutputStream.add(writ);
                    Thread t = new Thread(new ClientHandler(clientSocket, indx));
                    t.start();
                    System.out.println("got a connection");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } // close run
    } // close inner class

    public void go()

    {
        waitingSocket = new Socket[2];
        Thread t = new Thread(new RequestListner(0, chatmsg));
        t.start();
        t = new Thread(new RequestListner(1, gamemsg));
        t.start();
    }

    public static void main(String args[]){
        new VerySimpleChatServer().go();
    }
    public void tellEveryone(String message)  {
        try {
            for(int i=0;i<clientOutputStream.size();i++) {
                PrintWriter w = (PrintWriter) clientOutputStream.get(i);
                try {
                w.println(message);
                w.flush();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    } // close tellEveryone
} // close class