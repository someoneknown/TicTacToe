package sample.messaging;

import javafx.scene.layout.FlowPane;

import java.net.Socket;

public class MessagingController {
    public MessagingController(Socket socket, FlowPane messagingPane) {

    }
}
